const VK = {}

VK.Emitter = class {
  constructor() {
    this.events = new Map()
  }

  getEvents(event) {
    return this.events.get(event) || []
  }

  setEvents(event, listeners) {
    this.events.set(event, listeners)
  }

  clear(event) {
    this.events.delete(event)
  }

  emit(event, ...args) {
    const listeners = this.getEvents(event)
    listeners.forEach((listener) => {
      listener(...args)
    })
  }

  on(event, callback) {
    const listeners = this.getEvents(event)
    listeners.push(callback)
    this.setEvents(event, listeners)
  }
}
