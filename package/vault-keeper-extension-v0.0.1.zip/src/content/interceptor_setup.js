VK.interceptor = new VK.Interceptor()

VK.interceptCookies = (cookies) => {
  VK.interceptor.on('request', (request) => {
    request.setheader('Cookie', cookies)
  })
}

VK.start = () => {
  VK.interceptor.setup()
}
