VK.InterceptedRequest = class InterceptedRequest {
  constructor(request) {
    this.request = request
  }

  getHeader(name) {
    return this.request.getResponseHeader(name)
  }

  setheader(name, value) {
    this.request.setRequestHeader(name, value)
  }

  replaceHeader(name, callback) {
    const value = this.getHeader(name)
    if (value) {
      const newValue = callback(value)
      this.setheader(name, newValue)
    }
  }
}

VK.Interceptor = class Interceptor extends VK.Emitter {
  constructor() {
    super()
  }

  setup() {
    const interceptor = this
    var _open = XMLHttpRequest.prototype.open

    window.XMLHttpRequest.prototype.open = function (method, url) {
      var _onreadystatechange = this.onreadystatechange,
        _this = this
      _this.onreadystatechange = function () {
        if (_this.readyState === 4 && _this.status === 200) {
          const req = new VK.InterceptedRequest(_this)
          interceptor.emit('request', req)
        }
        if (_onreadystatechange) _onreadystatechange.apply(this, arguments)
      }

      Object.defineProperty(this, 'onreadystatechange', {
        get: function () {
          return _onreadystatechange
        },
        set: function (value) {
          _onreadystatechange = value
        },
      })

      return _open.apply(_this, arguments)
    }
  }
}
