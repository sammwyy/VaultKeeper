(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.ts.1a373916.js")
    );
  })().catch(console.error);

})();
